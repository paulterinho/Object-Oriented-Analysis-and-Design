public class MessageSystemException extends Exception
{
	public MessageSystemException(String errMsg)
	{
		super(errMsg);
	}
	
}